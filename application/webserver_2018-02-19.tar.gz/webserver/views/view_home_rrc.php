<body>

<div id="container" style="width:100%; height:400px;" align="center">
	
	<img src="/npsmart/images/HUAWEI-LOGO.jpg" width="130" height="60" />
	
	

	<form method="post" accept-charset="utf-8" action="/npsmart/performance/rrc">
	<font size="4" color="blue"><b>RNC: </b></font>
	<input type="text" name="rnc"/>
	<font size="4" color="blue"><b>Cell: </b></font> 
	<input type="text" name="cellid"" />
	<input type="submit" name="mysubmit" value="Submit" />
<br><br><br><br><br>
	</form>


	<div id="body" style="width:700px; height:400px;">

	</div>

</div>

</body>
</html>