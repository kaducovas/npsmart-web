<!DOCTYPE html>
<html>
<head>

<title> Ambiente de Teste do CRUD</title>

		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta property="og:url" content="https://selectize.github.io/selectize.js/" />
		<meta property="og:image" content="https://selectize.github.io/selectize.js/images/og.png">
		<meta property="og:title" content="Selectize.js">
		<meta name="viewport" content="width=device-width">
		<link rel="stylesheet" href="//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700">
		<link rel="stylesheet" href="selectize.js-master/dist/css/selectize.default.css" data-theme="default">
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
		<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/7.3/highlight.min.js"></script>
		<script src="js/selectize.js"></script>
		

<style>

#menuCreateCluster{width:380px;height:600px;background:#e6e6e6;border-radius:8px;box-shadow:0 0 40px -10px #000;margin:0px auto;padding:20px 30px;max-width:calc(100vw - 40px);box-sizing:border-box;font-family:'Montserrat',sans-serif;position:relative}
h2{text-align:center;margin:10px 0;padding-bottom:10px;width:100%;color:#78788c;border-bottom:3px solid #78788c}
input{width:100%;padding:10px;box-sizing:border-box;background:none;outline:none;resize:none;border:0;font-family:'Montserrat',sans-serif;transition:all .3s;border-bottom:2px solid #bebed2}
input:focus{border-bottom:2px solid #78788c}
p:before{content:attr(type);display:block;margin:28px 0 0;font-size:20px;color:#5a5a5a}
button{padding:8px 12px;margin:0px 120px;font-family:'Montserrat',sans-serif;border:2px solid #78788c;background:0;color:#5a5a6e;cursor:pointer;transition:all .3s}
button:hover{background:#78788c;color:#fff}
span{margin:0 5px 0 15px}
#toLeft{float: left;}
#toRight{float: right;}	
#toLeft:hover{color: white; cursor: pointer}
#toRight:hover{color: white; cursor: pointer}
#divCreateCluster{display: block}
#divEditCluster{display: none}
#divDeleteCluster{display: none}	
</style>		
		
</head>


<body>

<div id="divCreateCluster">
	<div id="menuCreateCluster">

		<h2><i id="toLeft" class="fa fa-chevron-left"></i>Create a Cluster<i id="toRight" class="fa fa-chevron-right"></i></h2>
  
		<p type="Cluster Name:">
			<input id="cluster_name" placeholder="Special characters are not allowed."></input>
		</p>

		<p type="Cluster Technology:">
			<div id="wrapper2" style="width: 100%">
				<div class="demo">
					<div class="control-group">
						<select id="select-tech" class="demo-default" placeholder="Select a Technology ...">
							<option value="">Select a Technology...</option>
							<option value="GSM">GSM</option>
							<option value="UMTS">UMTS</option>
							<option value="LTE">LTE</option>
						</select>
					</div>
				</div>
			</div>
		</p>

		<p type="Cluster UF:">
			<div id="wrapper" style="width: 100%">
				<div class="demo">
					<div class="control-group">
						<select id="select-uf" class="demo-default" placeholder="Select a UF ..." disabled>
							<option value="">Select a UF...</option>
							<?php
								foreach($uf_lte as $row){	
									echo '<option value="'.$row->uf.'">'.$row->uf.'</option>';
								}
							?>
						</select>
					</div>
				</div>
			</div>
		</p>

		<p type="Cluster Sites:">
			<section class="demo" id="demo-max-items">
				<div class="sandbox" style="width:100%">
					<select disabled id="select-sites" name="state[]" multiple class="demo-default" style="width:100%" placeholder="Type a site name ...">
							<?php
								foreach($site_lte as $row){	
									echo '<option class="'.$row->uf.'" value="'.$row->site.'">'.$row->site.'</option>';
								}
							?>
					</select>
				</div>
			</section>	
		</p>

		<button id="create">CREATE</button>

		<div id="txtHint1"></div> 
		<div id="txtHint2"></div> 
		<div id="txtHint3"></div> 
	</div>
</div>

<div id="divEditCluster"></div>
<div id="divDeleteCluster"></div>

<script>
////////////////////////////////////////////////////// DECLARANDO VARIÁVEIS /////////////////////////////////////////

var select_tech, $select_tech;
var select_uf, $select_uf;
var select_sites, $select_sites;
var query_uf = "";
var query_sites = "";
var query_CreateCluster = "";

///////////////////////////////////////////////////// TECNOLOGIA ////////////////////////////////////////////////////

$select_tech = $('#select-tech').selectize({
	create: true,
	highlight: false,
	onChange: function(value) {
		select_uf.enable();
		if((value == "UMTS") || (value == "LTE")){
			query_uf = "SELECT distinct uf FROM "+value+"_control.claro_cluster order by uf";	
		}else{
			query_uf = "SELECT distinct uf FROM GSM_control.cells_db order by uf";	
		}
		showUF();	
	},
	dropdownParent: 'body'
});

///////////////////////////////////////////////////////// UF /////////////////////////////////////////////////////////

$select_uf = $('#select-uf').selectize({
	create: true,
	highlight: false,	
	sortField: {
		field: 'text',
		direction: 'asc'
	},
	onChange: function(value) {
		select_sites.enable();
		if(select_tech.getValue() == "UMTS"){
			query_sites = "SELECT distinct nodeb as node, uf FROM UMTS_control.cells_database WHERE uf = '"+value+"' order by nodeb";	
		}else if(select_tech.getValue() == "LTE"){
			query_sites = "SELECT distinct site as node, uf FROM lte_control.cells WHERE uf = '"+value+"' order by site";	
		}
		else{
			query_sites = "SELECT distinct bts as node, uf FROM GSM_control.cells_db WHERE uf = '"+value+"' order by bts";	
		}
		showSites();
	},
	dropdownParent: 'body'
});

////////////////////////////////////////////////////////// SITES ////////////////////////////////////////////////////

$select_sites = $('#select-sites').selectize({
    maxItems: 20,
	highlight: false,

});

///////////////////////////////////////////////////// BOTÃO CRIAR CHART /////////////////////////////////////////////

$('#create').click(function(){
	
var value = select_sites.getValue();
var str_value = value.toString();
var temp = new Array();
var cluster_name = $('#cluster_name').val();
var tech = select_tech.getValue();
var uf = select_uf.getValue();

temp = str_value.split(",");

if((cluster_name != "") && (uf != "")){
query_CreateCluster = "insert into teste_cluster (cluster,uf,user_created) values ('"+select_uf.getValue()+" - "+cluster_name+"','"+select_uf.getValue()+"',true)";
}else{
alert("Please write Cluster Name");	
}

CreateCluster();	
// for (i in temp) {
	// alert(temp[i]);
// }	

});

$('#toLeft').click(function(){
	

	
});

////////////////////////////////////////////////// AJAX REQUEST FOR UFs ////////////////////////////////////////////

function showUF() {

        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint1").innerHTML = this.responseText;
				eval(document.getElementById("showUF_js").innerHTML);
            }
        };
        xmlhttp.open("GET","/npsmart/quickreport_test/show_UF/?q1="+query_uf,true);
        xmlhttp.send();
		
    }
	
function showSites() {

        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint2").innerHTML = this.responseText;
				eval(document.getElementById("showSites_js").innerHTML);
            }
        };
        xmlhttp.open("GET","/npsmart/quickreport_test/show_Sites/?q2="+query_sites+"&q3="+query_CreateCluster,true);
        xmlhttp.send();
		
    }

function CreateCluster() {

        if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        } else {
            // code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                document.getElementById("txtHint3").innerHTML = this.responseText;
				//eval(document.getElementById("showSites_js").innerHTML);
            }
        };
        xmlhttp.open("GET","/npsmart/quickreport_test/show_Sites/?q2="+query_sites+"&q3="+query_CreateCluster,true);
        xmlhttp.send();
		
    }		

select_tech  = $select_tech[0].selectize;
select_uf = $select_uf[0].selectize;
select_sites  = $select_sites[0].selectize;


</script>

</body>
</html>