<div align=center>
<br>
<br>
<br>
<br>
<br>
<FONT SIZE="5">
O GSM DAILY AINDA NÃO POSSUI DADOS PARA ESTA GRANULARIDADE
</FONT>
<br>
<br>
<br>
<a style="color:#394E58" href = "/npsmart/gsm/daily"><i></u>RETORNAR A PÁGINA INICIAL DO GSM DAILY<u></i></a>
</div>
</body>
</html>