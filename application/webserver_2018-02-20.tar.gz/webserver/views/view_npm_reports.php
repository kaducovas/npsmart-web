<div id="container" class="main"> 

<br><br>
<div id="content" class="chart_content"><div id="graph1" class="chart1"></div></div>
<div id="content" class="chart_content"><div id="graph2" class="chart"></div></div>
<div style="clear: both;"></div>			
<div id="content" class="chart_content"><div id="graph3" class="chart"></div></div>			
<div id="content" class="chart_content"><div id="graph4" class="chart"></div></div>
<div style="clear: both;"></div>
<div id="content" class="chart_content"><div id="graph5" class="chart"></div></div>
<div id="content" class="chart_content"><div id="graph6" class="chart"></div></div>	
<div style="clear: both;"></div>			
<!--<div id="content" class="chart_content"><div id="graph7" class="chart"></div></div>
<div id="content" class="chart_content"><div id="graph8" class="chart"></div></div>
<div style="clear: both;"></div>			
<div id="content" class="chart_content"><div id="graph9" class="chart"></div></div>			
<div id="content" class="chart_content"><div id="graph10" class="chart"></div></div>
<div style="clear: both;"></div>-->

</form>
</div>
	<button id="export">Export all</button>
</body>
</html>