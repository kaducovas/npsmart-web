<br>
<!--<div id="content" class="chart_content"><div id="acc" class="chart1"></div></div>
<div id="content" class="chart_content"><div id="csfb" class="chart1"></div></div>
<div style="clear: both;"></div>
<div id="content" class="chart_content"><div id="drop" class="chart"></div></div>
<div id="content" class="chart_content"><div id="retention" class="chart"></div></div>	
<div style="clear: both;"></div>-->			

<div id="content" class="chart_content"><div id="dlthp" class="chart"></div></div>
<div id="content" class="chart_content"><div id="ulthp" class="chart"></div></div>
<div style="clear: both;"></div>
<div id="content" class="chart_content"><div id="utilization" class="chart"></div></div>
<div id="content" class="chart_content"><div id="handover" class="chart"></div></div>
<div style="clear: both;"></div>
<div id="content" class="chart_content"><div id="availability" class="chart"></div></div>			
<div id="content" class="chart_content"><div id="interference" class="chart"></div></div>			
<div style="clear: both;"></div>


</form>
</div>

</body>
</html>